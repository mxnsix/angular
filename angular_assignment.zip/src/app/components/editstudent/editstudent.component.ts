import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
import {StudentsService} from '../../students.service';
import {ActivatedRoute} from '@angular/router'

@Component({
  selector: 'app-editstudent',
  templateUrl: './editstudent.component.html',
  styleUrls: ['./editstudent.component.css']
})
export class EditstudentComponent implements OnInit{
  constructor(private student:StudentsService, private router: ActivatedRoute){}
  editStudent=new FormGroup({
    name: new FormControl(''),
    email:new FormControl(''),
    department:new FormControl(''),
    subject1:new FormControl(''),
    subject2:new FormControl(''),
    subject3:new FormControl(''),
    subject4:new FormControl(''),
    subject5:new FormControl(''),
      }
      );
      message:boolean=false;
    ngOnInit(): void {
      this.student.getStudentById(this.router.snapshot.params['id']).subscribe((result:any)=>{
        //console.log(result);
this.editStudent=new FormGroup({
  name:new FormControl(result['name']),
  email:new FormControl(result['email']),
department:new FormControl(result['department']),
subject1:new FormControl(result['subject1']),
subject2:new FormControl(result['subject1']),
subject3:new FormControl(result['subject1']),
subject4:new FormControl(result['subject1']),
subject5:new FormControl(result['subject1']),
});
        

    });
  }
    UpdateData(){
   console.log(this.editStudent.value);
   this.student.updateStudentData(this.router.snapshot.params['id'], this.editStudent.value).subscribe((result)=>{
    //console.log(result);
    this.message=true;
   })
    }
    removeMessage(){
      this.message=false;
    }

}

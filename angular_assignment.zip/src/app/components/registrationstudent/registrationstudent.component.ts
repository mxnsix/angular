import { Component } from '@angular/core';

@Component({
  selector: 'app-registrationstudent',
  templateUrl: './registrationstudent.component.html',
  styleUrls: ['./registrationstudent.component.css']
})
export class RegistrationstudentComponent {

}

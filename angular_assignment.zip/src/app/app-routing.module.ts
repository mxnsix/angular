import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AddstudentComponent} from './components/addstudent/addstudent.component';
import {EditstudentComponent} from './components/editstudent/editstudent.component';
import {ListstudentComponent} from './components/liststudent/liststudent.component';
import {LoginstudentComponent} from './components/loginstudent/loginstudent.component';
import {RegistrationstudentComponent} from './components/registrationstudent/registrationstudent.component';
const routes: Routes = [
  {
    path:'add',
    component:AddstudentComponent
  },
  {
    path:'edit/:id',
    component:EditstudentComponent
  },
  {
    path:'list',
    component:ListstudentComponent
  },
  {
    path:'login',
    component:LoginstudentComponent
  },
  {
    path:'register',
    component:RegistrationstudentComponent
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
